db_endpoint = 'foodatlas.cvc7tm9vqggx.us-east-2.rds.amazonaws.com'
db_username = 'postgres'
db_password = 'nacRackE'
db_port = 5432
db_name = 'foodAtlas'